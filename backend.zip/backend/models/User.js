import bcrypt from "bcryptjs";
import { getDB } from "../config/db.js";

// Find user by email
export const findUserByEmail = async (email) => {
  const db = getDB();
  const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
  return rows[0] || null;
};

// Find user by id
export const findUserById = async (id) => {
  const db = getDB();
  const [rows] = await db.query("SELECT * FROM users WHERE id = ?", [id]);
  return rows[0] || null;
};

// Create new user (hashes password inside)
export const createUser = async ({ username, email, password }) => {
  const db = getDB();

  // Hash password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const [result] = await db.query(
    "INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
    [username, email, hashedPassword]
  );

  return {
    id: result.insertId,
    username,
    email,
    password: hashedPassword,
  };
};

// Compare password
export const comparePassword = async (enteredPassword, storedHash) => {
  return bcrypt.compare(enteredPassword, storedHash);
};

// Remove password field before sending to client
export const sanitizeUser = (user) => {
  if (!user) return null;
  const { password, ...rest } = user;
  return rest;
};
